import { GoogleGenAI } from "@google/genai";
import { Opportunity } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeDeal = async (opportunity: Opportunity): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key missing. Cannot generate analysis.";
  }

  const prompt = `
    Analyze the following logistics sales opportunity and provide a brief, high-impact "Management Note".
    Focus on risk factors, next steps, or missing data. Keep it under 30 words.
    
    Data:
    Customer: ${opportunity.customer}
    Stage: ${opportunity.stage_name} (Stage ${opportunity.pipeline_stage})
    Days in Stage: ${opportunity.status.days_in_stage}
    Est Revenue: $${opportunity.financials.est_monthly_rev}
    Margin: ${opportunity.financials.est_margin_pct}%
    Last Activity: ${opportunity.status.last_activity}
    Stale: ${opportunity.health_signals.is_stale ? 'YES' : 'NO'}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "No analysis available.";
  } catch (error) {
    console.error("Gemini analysis failed:", error);
    return "Analysis failed due to service error.";
  }
};