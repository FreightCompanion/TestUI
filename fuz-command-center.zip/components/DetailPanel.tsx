import React, { useState, useEffect } from 'react';
import { X, Save, Wand2 } from 'lucide-react';
import { STAGES } from '../constants';
import { Opportunity, MODES, SEGMENTS } from '../types';
import { analyzeDeal } from '../services/geminiService';

interface DetailPanelProps {
  opportunity: Opportunity | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedOpp: Opportunity) => void;
}

export const DetailPanel: React.FC<DetailPanelProps> = ({ opportunity, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState<Opportunity | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (opportunity) {
      setFormData(JSON.parse(JSON.stringify(opportunity))); // Deep copy
    }
  }, [opportunity]);

  const handleChange = (field: string, value: any) => {
    if (!formData) return;
    setFormData(prev => {
      if (!prev) return null;
      // Handle nested updates
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        return {
          ...prev,
          [parent]: {
            ...(prev as any)[parent],
            [child]: value
          }
        };
      }
      return { ...prev, [field]: value };
    });
  };

  const handleModeToggle = (mode: string) => {
    if (!formData) return;
    const currentModes = formData.modes;
    const newModes = currentModes.includes(mode)
      ? currentModes.filter(m => m !== mode)
      : [...currentModes, mode];
    handleChange('modes', newModes);
  };

  const handleGenerateNote = async () => {
    if (!formData) return;
    setIsGenerating(true);
    const note = await analyzeDeal(formData);
    handleChange('management_note', note);
    setIsGenerating(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData) {
      // Recalculate weighted value if stage or revenue changed
      const stage = STAGES.find(s => s.id === formData.pipeline_stage);
      const prob = stage ? stage.probability : 0;
      const updatedFinancials = {
        ...formData.financials,
        weighted_value: formData.financials.est_monthly_rev * prob
      };
      
      // Update stage name based on ID
      const updatedStageName = STAGES.find(s => s.id === formData.pipeline_stage)?.name || '';

      onSave({
        ...formData,
        stage_name: updatedStageName,
        financials: updatedFinancials
      });
    }
  };

  if (!formData) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/20 backdrop-blur-sm z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Panel */}
      <div className={`fixed top-0 right-0 h-full w-full md:w-[500px] bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="h-full flex flex-col">
          
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-[#1A2B49] text-white">
            <div>
              <h2 className="text-xl font-bold">{formData.customer}</h2>
              <p className="text-blue-200 text-sm">ID: {formData.id}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <form id="opp-form" onSubmit={handleSubmit}>
              
              {/* Key Info */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Classification</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Customer Name</label>
                    <input 
                      type="text" 
                      value={formData.customer}
                      onChange={e => handleChange('customer', e.target.value)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Segment</label>
                    <select 
                      value={formData.segment}
                      onChange={e => handleChange('segment', e.target.value)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      {SEGMENTS.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Mode Mix</label>
                  <div className="flex flex-wrap gap-2">
                    {MODES.map(mode => (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => handleModeToggle(mode)}
                        className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                          formData.modes.includes(mode)
                            ? 'bg-[#1A2B49] text-white border-[#1A2B49]'
                            : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {mode}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Pipeline Status */}
              <div className="space-y-4 mt-8">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Pipeline Status</h3>
                
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Current Stage</label>
                    <select 
                      value={formData.pipeline_stage}
                      onChange={e => handleChange('pipeline_stage', parseInt(e.target.value))}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                    >
                      {STAGES.map(s => <option key={s.id} value={s.id}>{s.id}. {s.name} ({s.probability * 100}%)</option>)}
                    </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Target Close Date</label>
                    <input 
                      type="date" 
                      value={formData.close_date}
                      onChange={e => handleChange('close_date', e.target.value)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Ops Ready?</label>
                    <div className="flex items-center h-[38px]">
                        <button 
                        type="button"
                        onClick={() => handleChange('health_signals.ops_approved', !formData.health_signals.ops_approved)}
                        className={`w-12 h-6 rounded-full p-1 transition-colors ${formData.health_signals.ops_approved ? 'bg-green-500' : 'bg-slate-300'}`}
                        >
                        <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${formData.health_signals.ops_approved ? 'translate-x-6' : 'translate-x-0'}`} />
                        </button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Est. Monthly Rev ($)</label>
                    <input 
                      type="number" 
                      value={formData.financials.est_monthly_rev}
                      onChange={e => handleChange('financials.est_monthly_rev', parseInt(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Est. Gross Margin (%)</label>
                    <input 
                      type="number" 
                      value={formData.financials.est_margin_pct}
                      onChange={e => handleChange('financials.est_margin_pct', parseInt(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
              </div>

               {/* Activity & Notes */}
               <div className="space-y-4 mt-8">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Activity & Notes</h3>
                
                <div className="grid grid-cols-2 gap-4">
                   <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Last Contact</label>
                    <input 
                      type="date" 
                      value={formData.status.last_activity}
                      onChange={e => handleChange('status.last_activity', e.target.value)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                   </div>
                   <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Next Step</label>
                    <input 
                      type="text" 
                      value={formData.status.next_step}
                      onChange={e => handleChange('status.next_step', e.target.value)}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                   </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-sm font-medium text-slate-700">Management Note</label>
                    <button 
                      type="button"
                      onClick={handleGenerateNote}
                      disabled={isGenerating}
                      className="text-xs flex items-center gap-1 text-purple-600 hover:text-purple-700 disabled:opacity-50"
                    >
                      <Wand2 className="w-3 h-3" />
                      {isGenerating ? 'Analyzing...' : 'AI Assist'}
                    </button>
                  </div>
                  <textarea 
                    rows={4}
                    value={formData.management_note || ''}
                    onChange={e => handleChange('management_note', e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                    placeholder="Brief update on next steps or bottlenecks..."
                  />
                </div>
              </div>

            </form>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
             <button 
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 font-medium text-sm hover:text-slate-800"
            >
              Cancel
            </button>
            <button 
              type="submit"
              form="opp-form"
              className="px-6 py-2 bg-[#1A2B49] text-white font-medium text-sm rounded-lg hover:bg-[#2A436B] transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>

        </div>
      </div>
    </>
  );
};