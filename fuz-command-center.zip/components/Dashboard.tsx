import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  ScatterChart, Scatter, ZAxis, PieChart, Pie, Cell 
} from 'recharts';
import { useNavigate } from 'react-router-dom';
import { STAGES, COLORS, MONTHLY_TARGET } from '../constants';
import { Activity, TrendingUp, AlertTriangle, DollarSign } from 'lucide-react';
import { Opportunity } from '../types';

interface DashboardProps {
  opportunities: Opportunity[];
}

const formatCurrency = (val: number) => 
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

interface MetricTileProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  subtext?: string;
  onClick?: () => void;
}

const MetricTile: React.FC<MetricTileProps> = ({ title, value, icon, subtext, onClick }) => (
  <div 
    onClick={onClick}
    className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-start justify-between hover:shadow-md transition-shadow cursor-pointer"
  >
    <div>
      <p className="text-slate-500 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-2xl font-bold text-[#1A2B49]">{value}</h3>
      {subtext && <p className="text-slate-400 text-xs mt-1">{subtext}</p>}
    </div>
    <div className="p-3 bg-slate-50 rounded-lg">
      {icon}
    </div>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ opportunities }) => {
  const navigate = useNavigate();
  
  // --- Derived Metrics ---
  const totalPipelineValue = opportunities.reduce((acc, curr) => acc + curr.financials.est_monthly_rev, 0);
  
  const weightedForecast = opportunities.reduce((acc, curr) => {
    const stage = STAGES.find(s => s.id === curr.pipeline_stage);
    return acc + (curr.financials.est_monthly_rev * (stage?.probability || 0));
  }, 0);

  const pipelineCoverage = (totalPipelineValue / MONTHLY_TARGET) * 100;

  const proposalAndAbove = opportunities.filter(o => o.pipeline_stage >= 5);
  const avgMargin = proposalAndAbove.length > 0
    ? proposalAndAbove.reduce((acc, curr) => acc + curr.financials.est_margin_pct, 0) / proposalAndAbove.length
    : 0;

  // --- Chart Data Preparation ---

  // 1. Funnel Data
  const funnelData = STAGES.map(stage => {
    const stageOpps = opportunities.filter(o => o.pipeline_stage === stage.id);
    return {
      name: stage.name,
      id: stage.id,
      count: stageOpps.length,
      value: stageOpps.reduce((acc, curr) => acc + curr.financials.est_monthly_rev, 0),
      isFocus: stage.isFocus
    };
  });

  // 2. Velocity Data
  const velocityData = opportunities.map(o => ({
    x: o.status.days_in_stage,
    y: o.financials.est_monthly_rev,
    z: o.financials.est_margin_pct,
    name: o.customer,
    stage: o.stage_name,
    id: o.id // Include ID for drill-down
  }));

  // 3. Mode Mix Data
  const modeCounts: Record<string, number> = {};
  opportunities.forEach(o => {
    o.modes.forEach(m => {
      modeCounts[m] = (modeCounts[m] || 0) + 1;
    });
  });
  const modeData = Object.entries(modeCounts).map(([name, value]) => ({ name, value }));
  const MODE_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#6366F1'];

  // 4. At Risk List
  const atRiskList = opportunities.filter(o => {
    const lastActivity = new Date(o.status.last_activity);
    const diffTime = Math.abs(Date.now() - lastActivity.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
    // Filter logic: Stages 3-6 AND > 7 days inactive
    return o.pipeline_stage >= 3 && o.pipeline_stage <= 6 && diffDays > 7;
  });

  // --- Drill Down Handlers ---
  
  const handleBarClick = (data: any) => {
    // When clicking a Bar, data is the payload for that specific bar
    if (data && data.id) {
        navigate(`/manager?stage=${data.id}`);
    }
  };

  const handleYAxisClick = (data: any) => {
    // When clicking YAxis Label, find the stage by name
    const stage = STAGES.find(s => s.name === data.value);
    if (stage) {
        navigate(`/manager?stage=${stage.id}`);
    }
  };

  const handleModeClick = (data: any) => {
     navigate(`/manager?mode=${data.name}`);
  };

  const handleVelocityClick = (data: any) => {
     // Recharts scatter click usually returns the node data directly or in an event wrapper
     if (data && data.id) {
         navigate(`/manager?id=${data.id}`);
     } else if (data && data.payload && data.payload.id) {
          navigate(`/manager?id=${data.payload.id}`);
     }
  };

  return (
    <div className="p-6 space-y-8 animate-fade-in">
      
      {/* A. North Star Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricTile 
          title="Total Pipeline Value" 
          value={formatCurrency(totalPipelineValue)} 
          icon={<DollarSign className="w-5 h-5 text-blue-400" />} 
          onClick={() => navigate('/manager')}
        />
        <MetricTile 
          title="Weighted Forecast" 
          value={formatCurrency(weightedForecast)} 
          icon={<Activity className="w-5 h-5 text-green-400" />} 
          onClick={() => navigate('/manager')}
        />
        <MetricTile 
          title="Pipeline Coverage" 
          value={`${pipelineCoverage.toFixed(1)}%`} 
          subtext={`Target: ${formatCurrency(MONTHLY_TARGET)}`}
          icon={<TrendingUp className="w-5 h-5 text-purple-400" />} 
          onClick={() => navigate('/manager')}
        />
        <MetricTile 
          title="Avg Margin (Stg 5+)" 
          value={`${avgMargin.toFixed(1)}%`} 
          icon={<TrendingUp className="w-5 h-5 text-orange-400" />} 
          onClick={() => navigate('/manager?minStage=5')}
        />
      </div>

      {/* B. Visualizations Body */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* The 8-Stage Funnel */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-bold text-[#1A2B49] mb-4">Pipeline by Stage</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                layout="vertical" 
                data={funnelData} 
                margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
              >
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={100} 
                  tick={{fontSize: 12, cursor: 'pointer'}} 
                  onClick={handleYAxisClick}
                />
                <Tooltip 
                  cursor={{fill: '#F1F5F9'}}
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar 
                  dataKey="value" 
                  radius={[0, 4, 4, 0]} 
                  barSize={20} 
                  onClick={handleBarClick}
                  cursor="pointer"
                >
                  {funnelData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.isFocus ? COLORS.focusBlue : '#CBD5E1'} cursor="pointer" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mode Mix */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-[#1A2B49] mb-4">Mode Mix</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={modeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  onClick={handleModeClick}
                  className="cursor-pointer outline-none"
                >
                  {modeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={MODE_COLORS[index % MODE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              {modeData.map((entry, index) => (
                <div key={entry.name} className="flex items-center text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full mr-1" style={{backgroundColor: MODE_COLORS[index % MODE_COLORS.length]}}></span>
                  {entry.name}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Velocity Tracker */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-bold text-[#1A2B49] mb-4">Velocity Tracker (Revenue vs Days)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <XAxis type="number" dataKey="x" name="Days in Pipeline" unit="d" />
                <YAxis type="number" dataKey="y" name="Revenue" unit="$" />
                <ZAxis type="number" dataKey="z" range={[60, 400]} name="Margin" unit="%" />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter 
                    name="Opportunities" 
                    data={velocityData} 
                    fill={COLORS.navy} 
                    fillOpacity={0.6}
                    onClick={handleVelocityClick}
                    className="cursor-pointer"
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* At-Risk List */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="text-amber-500 w-5 h-5" />
            <h3 className="text-lg font-bold text-[#1A2B49]">At-Risk (7+ Days Inactive)</h3>
          </div>
          <div className="overflow-y-auto max-h-64">
            {atRiskList.length === 0 ? (
              <p className="text-slate-400 text-sm">No at-risk accounts.</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="pb-2">Account</th>
                    <th className="pb-2">Stage</th>
                    <th className="pb-2 text-right">Last Act.</th>
                  </tr>
                </thead>
                <tbody>
                  {atRiskList.map(opp => (
                    <tr 
                        key={opp.id} 
                        className="border-b border-slate-50 hover:bg-amber-50 transition-colors cursor-pointer"
                        onClick={() => navigate(`/manager?id=${opp.id}`)}
                    >
                      <td className="py-2 font-medium text-[#1A2B49]">{opp.customer}</td>
                      <td className="py-2 text-slate-500">{opp.pipeline_stage}</td>
                      <td className="py-2 text-right text-amber-600 font-medium">{opp.status.last_activity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};