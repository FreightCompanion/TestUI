import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar, Filter } from 'lucide-react';

type FilterType = 'month' | 'quarter' | 'custom';

interface DateFilterProps {
  onFilterChange: (start: Date, end: Date) => void;
}

export const DateFilter: React.FC<DateFilterProps> = ({ onFilterChange }) => {
  const [filterType, setFilterType] = useState<FilterType>('quarter'); // Default to quarter view
  const [currentDate, setCurrentDate] = useState(new Date()); // For month view
  
  // Initialize quarter
  const currentQ = Math.floor((new Date().getMonth() + 3) / 3);
  const [selectedQuarter, setSelectedQuarter] = useState<number>(currentQ);
  
  // Initialize custom range
  const today = new Date();
  const startOfYear = new Date(today.getFullYear(), 0, 1);
  const endOfYear = new Date(today.getFullYear(), 11, 31);
  
  const [customRange, setCustomRange] = useState<{start: string, end: string}>({
    start: startOfYear.toISOString().split('T')[0],
    end: endOfYear.toISOString().split('T')[0]
  });

  useEffect(() => {
    let start = new Date();
    let end = new Date();

    if (filterType === 'month') {
      start = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      end = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0); // Last day of month
    } else if (filterType === 'quarter') {
      const qStartMonth = (selectedQuarter - 1) * 3;
      start = new Date(currentDate.getFullYear(), qStartMonth, 1);
      end = new Date(currentDate.getFullYear(), qStartMonth + 3, 0);
    } else if (filterType === 'custom') {
      start = new Date(customRange.start);
      end = new Date(customRange.end);
      // Adjust end date to cover the full day if needed, but simple comparison usually works
    }

    // Set hours to encompass full days
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);

    onFilterChange(start, end);
  }, [filterType, currentDate, selectedQuarter, customRange]);

  const handleMonthChange = (delta: number) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + delta);
    setCurrentDate(newDate);
  };

  const currentYear = currentDate.getFullYear();
  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  return (
    <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-lg border border-slate-200">
      
      {/* Type Selector */}
      <div className="flex gap-1 mr-2 bg-white rounded-md p-0.5 border border-slate-200 shadow-sm">
        {(['month', 'quarter', 'custom'] as FilterType[]).map((t) => (
          <button
            key={t}
            onClick={() => setFilterType(t)}
            className={`px-3 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
              filterType === t 
                ? 'bg-[#1A2B49] text-white shadow-sm' 
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 px-2 border-l border-slate-300 min-w-[200px] justify-center">
        
        {filterType === 'month' && (
          <div className="flex items-center gap-2 text-sm font-medium text-[#1A2B49]">
            <button onClick={() => handleMonthChange(-1)} className="p-1 hover:bg-slate-200 rounded-full">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="w-32 text-center">{monthName} {currentYear}</span>
            <button onClick={() => handleMonthChange(1)} className="p-1 hover:bg-slate-200 rounded-full">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {filterType === 'quarter' && (
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4].map((q) => (
              <button
                key={q}
                onClick={() => setSelectedQuarter(q)}
                className={`w-8 h-8 flex items-center justify-center rounded-full text-xs font-bold transition-all ${
                  selectedQuarter === q
                    ? 'bg-blue-500 text-white shadow-md scale-105'
                    : 'bg-white text-slate-500 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                Q{q}
              </button>
            ))}
            <span className="ml-2 text-xs text-slate-400 font-medium">{currentYear}</span>
          </div>
        )}

        {filterType === 'custom' && (
          <div className="flex items-center gap-2 text-sm">
            <input 
              type="date"
              value={customRange.start}
              onChange={(e) => setCustomRange(prev => ({ ...prev, start: e.target.value }))}
              className="px-2 py-1 rounded border border-slate-300 text-slate-700 w-32 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <span className="text-slate-400">-</span>
            <input 
              type="date"
              value={customRange.end}
              onChange={(e) => setCustomRange(prev => ({ ...prev, end: e.target.value }))}
              className="px-2 py-1 rounded border border-slate-300 text-slate-700 w-32 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        )}
      </div>
    </div>
  );
};