import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { STAGES, COLORS } from '../constants';
import { Opportunity } from '../types';
import { AlertCircle, CheckCircle2, MoreHorizontal, ArrowRight, Filter, X } from 'lucide-react';

interface OpportunityManagerProps {
  opportunities: Opportunity[];
  onSelect: (opp: Opportunity) => void;
}

export const OpportunityManager: React.FC<OpportunityManagerProps> = ({ opportunities, onSelect }) => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const getStageColor = (stageId: number) => {
    if (stageId >= 7) return 'bg-green-100 text-green-800';
    if (stageId >= 5) return 'bg-blue-100 text-blue-800';
    if (stageId >= 3) return 'bg-indigo-100 text-indigo-800';
    return 'bg-slate-100 text-slate-600';
  };

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  // --- Active Filter Display Logic ---
  const activeFilters = [];
  if (searchParams.get('stage')) {
    const stageId = parseInt(searchParams.get('stage')!);
    const stageName = STAGES.find(s => s.id === stageId)?.name;
    activeFilters.push(`Stage: ${stageId}. ${stageName}`);
  }
  if (searchParams.get('minStage')) {
     activeFilters.push(`Stage ${searchParams.get('minStage')}+`);
  }
  if (searchParams.get('mode')) {
    activeFilters.push(`Mode: ${searchParams.get('mode')}`);
  }
  if (searchParams.get('id')) {
    activeFilters.push(`ID: ${searchParams.get('id')}`);
  }

  const clearFilters = () => {
    navigate('/manager');
  };

  return (
    <div className="p-6">
      
      {/* Active Filters Banner */}
      {activeFilters.length > 0 && (
        <div className="mb-6 flex items-center justify-between bg-blue-50 border border-blue-100 p-4 rounded-lg">
          <div className="flex items-center gap-3">
             <Filter className="w-5 h-5 text-blue-600" />
             <div className="flex gap-2">
                <span className="text-sm font-medium text-blue-900">Active Filters:</span>
                {activeFilters.map((f, i) => (
                    <span key={i} className="px-2 py-0.5 bg-white text-blue-700 text-xs font-bold rounded border border-blue-200 shadow-sm">
                        {f}
                    </span>
                ))}
             </div>
          </div>
          <button 
            onClick={clearFilters}
            className="text-sm text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium px-3 py-1 hover:bg-white rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
            Clear Filters
          </button>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-[#1A2B49] text-white uppercase text-xs font-semibold tracking-wider">
              <tr>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4">Segment</th>
                <th className="px-6 py-4">Modes</th>
                <th className="px-6 py-4">Stage</th>
                <th className="px-6 py-4">Close Date</th>
                <th className="px-6 py-4 text-right">Est. Rev</th>
                <th className="px-6 py-4 text-right">Margin</th>
                <th className="px-6 py-4 text-center">Ops Ready</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {opportunities.length === 0 ? (
                <tr>
                    <td colSpan={9} className="px-6 py-12 text-center text-slate-400">
                        No opportunities match the selected filters.
                    </td>
                </tr>
              ) : (
                opportunities.map((opp) => (
                    <tr 
                    key={opp.id} 
                    onClick={() => onSelect(opp)}
                    className="hover:bg-blue-50/50 cursor-pointer transition-colors group"
                    >
                    <td className="px-6 py-4 font-medium text-[#1A2B49]">{opp.customer}</td>
                    <td className="px-6 py-4 text-slate-500">{opp.segment}</td>
                    <td className="px-6 py-4">
                        <div className="flex gap-1">
                        {opp.modes.slice(0, 2).map(m => (
                            <span key={m} className="px-2 py-0.5 rounded-md bg-slate-100 text-xs text-slate-600 border border-slate-200">
                            {m}
                            </span>
                        ))}
                        {opp.modes.length > 2 && <span className="text-xs text-slate-400">+{opp.modes.length - 2}</span>}
                        </div>
                    </td>
                    <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStageColor(opp.pipeline_stage)}`}>
                        {opp.pipeline_stage}. {opp.stage_name}
                        </span>
                    </td>
                    <td className="px-6 py-4 text-slate-500 font-medium">{opp.close_date}</td>
                    <td className="px-6 py-4 text-right font-medium">{formatCurrency(opp.financials.est_monthly_rev)}</td>
                    <td className="px-6 py-4 text-right text-slate-500">{opp.financials.est_margin_pct}%</td>
                    <td className="px-6 py-4 text-center">
                        {opp.health_signals.ops_approved ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
                        ) : (
                        <div className="w-5 h-5 mx-auto rounded-full border-2 border-slate-200" />
                        )}
                    </td>
                    <td className="px-6 py-4 text-right text-slate-400">
                        <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </td>
                    </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};